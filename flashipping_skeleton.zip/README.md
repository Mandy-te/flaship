# 🚀 Flashipping Skeleton
Repo skeleton pou sit Flashipping.

## Deploy sou Netlify
1. Konekte repo a ak Netlify
2. Li ap pran `pages/` kòm folder piblik
3. Site la ap dispo imedyatman
