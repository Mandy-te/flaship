window.addEventListener("load", () => {
  document.getElementById("loader").style.display = "none";
});
